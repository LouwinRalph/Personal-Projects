package com.example.act2signupform

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class UserAdapter(private val users: List<UserData>) :
    RecyclerView.Adapter<UserAdapter.UserViewHolder>() {

    class UserViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nameCell: TextView = itemView.findViewById(R.id.nameCell)
        val addressCell: TextView = itemView.findViewById(R.id.addressCell)
        val emailCell: TextView = itemView.findViewById(R.id.emailCell)
        val phoneCell: TextView = itemView.findViewById(R.id.phoneCell)
        val dobCell: TextView = itemView.findViewById(R.id.dobCell)
        val genderCell: TextView = itemView.findViewById(R.id.genderCell)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.user_item, parent, false)
        return UserViewHolder(view)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val user = users[position]
        holder.nameCell.text = user.name
        holder.addressCell.text = user.address
        holder.emailCell.text = user.email
        holder.phoneCell.text = user.phone
        holder.dobCell.text = user.dob
        holder.genderCell.text = user.gender
    }

    override fun getItemCount(): Int = users.size
}
