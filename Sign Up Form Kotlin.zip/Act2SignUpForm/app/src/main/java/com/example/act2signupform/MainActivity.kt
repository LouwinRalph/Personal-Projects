package com.example.act2signupform

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

data class UserData(
    val name: String,
    val address: String,
    val email: String,
    val phone: String,
    val dob: String,
    val gender: String
)

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private val userList = mutableListOf<UserData>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val nameInput = findViewById<EditText>(R.id.nameInput)
        val addressInput = findViewById<EditText>(R.id.addressInput)
        val emailInput = findViewById<EditText>(R.id.emailInput)
        val phoneInput = findViewById<EditText>(R.id.phoneInput)
        val dobInput = findViewById<EditText>(R.id.dobInput)
        val genderGroup = findViewById<RadioGroup>(R.id.genderGroup)
        val submitButton = findViewById<Button>(R.id.submitButton)
        recyclerView = findViewById(R.id.dataRecyclerView)

        val adapter = UserAdapter(userList)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        submitButton.setOnClickListener {
            val gender = when (genderGroup.checkedRadioButtonId) {
                R.id.maleRadio -> "Male"
                R.id.femaleRadio -> "Female"
                else -> "Unspecified"
            }

            val user = UserData(
                nameInput.text.toString(),
                addressInput.text.toString(),
                emailInput.text.toString(),
                phoneInput.text.toString(),
                dobInput.text.toString(),
                gender
            )

            userList.add(user)
            adapter.notifyItemInserted(userList.size - 1)
            recyclerView.visibility = View.VISIBLE
        }
    }
}
